import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import Main from './Components/Main'
import './Components/styles/main.css'

ReactDOM.render(<Main/>, document.getElementById('root'))