import React, {useState} from "react"
import './styles/searchbar.css'
import Main from './Main'
import User from './User'

const Searchbar = (usernames) => {

    // const userList = fetch('https://jsonplaceholder.typicode.com/users')
    //     .then((res) => res.json())
    //     .catch((error) => {
    //         console.log(error);
    //     })

    const [searchInput, setSearchInput] = useState('');

    //const p = [1,2,3,4,5]

    const handleChange = (e) => {
        e.preventDefault();
        setSearchInput(e.target.value);
      };
      
      if (searchInput.length > 0) {
        //input = input.toLowerCase();
        let x = document.getElementsByClassName(usernames);
          
        for (const username of x) { 
            
            let name = username.textContent.toLowerCase();

            if(name.includes(searchInput))
            {
                username.style.display = 'block';
            }
            else
            {
                username.style.display = 'none';
            }
        }
      }

      return (
        <div>
            <input
            class='searchbar'
            type="search"
            placeholder="Search a username..."
            onChange={handleChange}
            value={searchInput} 
            />
        </div>
        )


}

export default Searchbar