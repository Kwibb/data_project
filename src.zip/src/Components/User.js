import React from "react";
import './styles/data.css'

const User = ({id,name,username,email}) => {
    return(
        <div className='data'>
            {/* <span>{id}</span> */}
            <span>{name}</span>
            <span>{username}</span>
            <span>{email}</span>
        </div>
    )
}

export default User